#include <stdio.h>
void my_delay();
void turn_left();
void turn_right();
void move_forward();
void move_backward();
void park();
void follow_line();
void CCPPWM_init(void);
void remote();
void stop();

void main(){

unsigned int k;
TRISD=0b00000000; //TRISD initialized to 0 (output)
PORTD=0b00000000; //PORTD initialized to 0
TRISC = 0xF0;
TRISB = 0x83;
CCPPWM_init();

while(1){
if((PORTB & 0x01) && (PORTB & 0x02)){ park();} // both sensors detected black lines >> stop
          else if(PORTB&0x02){ turn_left(); } //left sensor detects a black line >> turns left
          else if (PORTB&0x01){ turn_right(); } // right sensor detects a black line >> turns right
          else  { move_forward(); } // no black lines are detected on both sensors >> moves forward
     /* if  ((PORTC & 0x10) && !(PORTC & 0x20) && !(PORTC & 0x40) && (PORTC & 0x80))
 turn_right();
else if  (!(PORTC & 0x10) && (PORTC & 0x20) && !(PORTC & 0x40) && (PORTC & 0x80))
turn_left();
else if  (!(PORTC & 0x10) && !(PORTC & 0x20) && !(PORTC & 0x40) && (PORTC & 0x80))
move_forward();
else if  ((PORTC & 0x10) && (PORTC & 0x20) && !(PORTC & 0x40) && (PORTC & 0x80))
move_backward();
else if  (!(PORTC & 0x10) && !(PORTC & 0x20) && (PORTC & 0x40) && (PORTC & 0x80))
remote();
else if  (!(PORTC & 0x10) && !(PORTC & 0x20) && !(PORTC & 0x40) && !(PORTC & 0x80))
 stop(); 
 */
  } }
void move_forward() {
 PORTD = 0x05; // 0000 0101 >> both motors are on and moving forward
}

void move_backward() {
 PORTD = 0x0A; // 0000 1010 >> both motors are on and moving backwards
}

void turn_right() {
 PORTD = 0x09; // 0000 1001 >> left motor moves forward and right motor moves backwards
}

void turn_left() {
 PORTD = 0x06; // 0000 0110 >> right motor moves forward and left motor moves backwards
}

void stop(){
PORTD=0x00;  //both motors stop
}

void my_delay(unsigned int mscnt){      //delay, 1000 = 1 second
     unsigned int ms;
     unsigned int cnt;
     for(ms=0;ms<mscnt;ms++){
      for(cnt=0;cnt<155;cnt++);//1ms
     }
}
void park(){         //parking function
PORTD=0x00;
my_delay(1000);
if((PORTB &0x80)){    //if upper IR detects an object the car will go the the next slot
turn_left();
my_delay(500);
follow_line(); }
else{
move_forward();
my_delay(200);
follow_line();}
}

void follow_line(){


  if((PORTB & 0x01) && (PORTB & 0x02)){PORTD = 0X00;}// both sensors detected black lines >> stop
          else if(PORTB&0x02){ turn_left(); } //left sensor detects a black line >> turns left
          else if (PORTB&0x01){ turn_right(); } // right sensor detects a black line >> turns right
          else  { move_forward(); } // no black lines are detected on both sensors >> moves forward
}

void CCPPWM_init(void){ //Configure CCP1 and CCP2 at 2ms period with 50% duty cycle
  T2CON = 0x07;//enable Timer2 at Fosc/4 with 1:16 prescaler (8 uS percount 2000uS to count 250 counts)
  CCP1CON = 0x0C;//enable PWM for CCP1
  CCP2CON = 0x0C;//enable PWM for CCP2
  PR2 = 250;// 250 counts =8uS *250 =2ms period
  TRISC = 0x00;
  CCPR1L= 100;  //pc2
  CCPR2L= 100;      //pc1
}
void remote(){
if((PORTB & 0x01) && (PORTB & 0x02)){ park();} // both sensors detected black lines >> stop
          else if(PORTB&0x02){ turn_left(); } //left sensor detects a black line >> turns left
          else if (PORTB&0x01){ turn_right(); } // right sensor detects a black line >> turns right
          else  { move_forward(); } // no black lines are detected on both sensors >> moves forward
          }

/* ---------------------------------------------------------------

in PORTD:
 bits 0 and 1 are for the left motor
 bits 2 and 3 are for the right sensor

00 -> stop
01 -> forward
10 -> backwards

----------------------------------------------------------------*/