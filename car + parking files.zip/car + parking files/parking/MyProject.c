#define LcdDataBus      PORTD    //configure data bus PD4:PD7
#define LcdControlBus   PORTD    //configure control bus PD0:PD2

#define LcdDataBusDirnReg   TRISD

#define LCD_RS     0
#define LCD_RW     1
#define LCD_EN     2

 int x=0,y=0,siu=0; //counters for parking slots


void myDelay(unsigned int mscnt){
     unsigned int ms;
     unsigned int cnt;
     for(ms=0;ms<mscnt;ms++){
      for(cnt=0;cnt<155;cnt++);//1ms
     }
}
void Lcd_CmdWrite(char cmd) // Function to send the command to LCD.
{
    LcdDataBus = (cmd & 0xF0);     //Send higher nibble
    LcdControlBus &= ~(1<<LCD_RS); // Send LOW pulse on RS pin for selecting Command register
    LcdControlBus &= ~(1<<LCD_RW); // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);  // Generate a High-to-low pulse on EN pin
//
    myDelay(50);
    LcdControlBus &= ~(1<<LCD_EN);
//
    myDelay(100);

    LcdDataBus = ((cmd<<4) & 0xF0); //Send Lower nibble
    LcdControlBus &= ~(1<<LCD_RS);  // Send LOW pulse on RS pin for selecting Command register
    LcdControlBus &= ~(1<<LCD_RW);  // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);   // Generate a High-to-low pulse on EN pin
//
    myDelay(50);
    LcdControlBus &= ~(1<<LCD_EN);
//
    myDelay(100);
}

void Lcd_DataWrite(char dat) // Function to send the Data to LCD.
{
    LcdDataBus = (dat & 0xF0);      //Send higher nibble
    LcdControlBus |= (1<<LCD_RS);   // Send HIGH pulse on RS pin for selecting data register
    LcdControlBus &= ~(1<<LCD_RW);  // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);   // Generate a High-to-low pulse on EN pin
  //
    myDelay(50);
    LcdControlBus &= ~(1<<LCD_EN);
  //
    myDelay(100);

    LcdDataBus = ((dat<<4) & 0xF0);  //Send Lower nibble
    LcdControlBus |= (1<<LCD_RS);    // Send HIGH pulse on RS pin for selecting data register
    LcdControlBus &= ~(1<<LCD_RW);   // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);    // Generate a High-to-low pulse on EN pin
    //
    myDelay(50);
    LcdControlBus &= ~(1<<LCD_EN);
   //
    myDelay(10);
}



int main()
{
    char i,j,out[7],a[]={"available slots:"};
    /*
    i,j ==> counters
    out ==> to take string coverted from int
    */

        TRISB = 0x00; //TRISB initialized to 0 (output)
        PORTB = 0x00; //PORTB initialized to 0
        TRISC = 0xFF;    //TRISC initialized to 1 (INPUT)
while(1){

          if(PORTC & 0x01)    //first IR detects a body
          {
           PORTB = PORTB & 0xFE;      //PORTB= 1111 1110  >> to make sure bit 0 is 0
           PORTB = PORTB | 0x02;      //PORTB= 0000 0010  >> to make sure all bits are 0 except bit 1
           x=1;                       // parking 1 is empty
          }

         else           //LED is red, parking occupied
         {
           PORTB = PORTB & 0xFD;       //PORTB= 1111 1101    >> to make sure bit 1 is 0
           PORTB = PORTB | 0x01;       //PORTB= 0000 0001    >> to make sure all bits are 0 except bit 0
           x=0;                        //parking 1 is occupied
         }



         if(PORTC & 0x02)   //Second IR detects a body
          {
          PORTB = PORTB & 0xFB;   //PORTB= 1111 1011  >> to make sure bit 2 is 0
           PORTB = PORTB | 0x08;  //PORTB= 0000 1000  >> to make sure all bits are 0 except bit 3
           y=1;                   //parking 2 is empty
          }

         else
         {

           PORTB = PORTB & 0xF7;  //PORTB= 1111 0111    >> to make sure bit 2 is 1
           PORTB = PORTB | 0x04;  //PORTB= 0000 0100  >> to make sure all bits are 0 except bit 2
           y=0;                   //parking 2 is occupied
         }
           siu=x+y;               //sum of available slots

    LcdDataBusDirnReg = 0x00;  // Configure all the LCD pins as output

                               //built in functions
    Lcd_CmdWrite(0x02);        // Initialize Lcd in 4-bit mode
    Lcd_CmdWrite(0x28);        // enable 5x7 mode for chars
    Lcd_CmdWrite(0x0E);        // Display OFF, Cursor ON
    Lcd_CmdWrite(0x01);        // Clear Display
    Lcd_CmdWrite(0x80);        // Move the cursor to beginning of first line

    Lcd_CmdWrite(0x01);        // Clear Display
    for(i=0;a[i]!=0;i++)
    {
        Lcd_DataWrite(a[i]);   // prints "availabe slots:" on the LCD
    }
       Lcd_CmdWrite(0xc0);     //new line
      IntToStr(siu,out);       //converts int to string
       for(j=0;out[j]!=0;j++)
    {
        Lcd_DataWrite(out[j]); //prints number of available slots
    }
      }
}
